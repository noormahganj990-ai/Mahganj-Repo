def atbash_cipher(text):
    result = ""

    for char in text:
        if char.isalpha():
            
            if char.isupper():
                result += chr(65 + (25 - (ord(char) - 65)))
            
            else:
                result += chr(97 + (25 - (ord(char) - 97)))
        else:
            
            result += char

    return result

def main():
    print("Atbashed Cipher")
    plaintext = input("plaintext: ")

    
    encrypted = atbash_cipher(plaintext)
    print("\nEncrypted:", encrypted)

    
    decrypted = atbash_cipher(encrypted)
    print("Decrypted:", decrypted)
    
if __name__ == "main":
    main()
